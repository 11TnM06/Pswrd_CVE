.. _mozilla_projects_nss_jss_build_instructions_for_jss_4_4_x:

Build instructions for JSS 4.4.x
================================

.. _build_instructions_for_jss_4.4.x:

`Build Instructions for JSS 4.4.x <#build_instructions_for_jss_4.4.x>`__
------------------------------------------------------------------------

.. container::

   Newsgroup: `mozilla.dev.tech.crypto <news://news.mozilla.org/mozilla.dev.tech.crypto>`__

   To build JSS see `Upstream JSS Build/Test
   Instructions <https://hg.mozilla.org/projects/jss/file/tip/README>`__

   `Next, you should read the instructions
   on <https://hg.mozilla.org/projects/jss/file/tip/README>`__ `using JSS <Using_JSS>`__.