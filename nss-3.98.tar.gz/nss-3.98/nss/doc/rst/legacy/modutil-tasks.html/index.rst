.. _mozilla_projects_nss_modutil-tasks_html:

modutil-tasks.html
==================

.. _nss_security_tools_modutil_tasks:

`NSS Security Tools: modutil Tasks <#nss_security_tools_modutil_tasks>`__
-------------------------------------------------------------------------

.. container::

   Newsgroup: `mozilla.dev.tech.crypto <news://news.mozilla.org/mozilla.dev.tech.crypto>`__

.. _task_list:

`Task List <#task_list>`__
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. container::

   #. The jar installation script is very fragile with respect to platform definitions (especially
      version numbers). A fix was made for "HPUX B.11.00," but issues may still arise for platforms
      like "Linux 2.2.12-20." Documentation needs to be explicit about the use of Fo